var express = require('express');
var app = express();

app.use(express.static('public'));

var dictionary;
var fs = require('fs');

fs.readFile("words.json", 'utf8', function(err, data){
    dictionary = JSON.parse(data.trim());
});


// res.send(dictionary[word]);

// app.get('/getinfo', function(req, res){
    
// });  

app.get('/dictionary', function(req, res){
    var word = req.query['word'];
    res.status(200).send(dictionary[word]);
    
    // res.header('Content-Type', 'application/json');
    res.status(200).send(json);
});


});


app.listen(3000);