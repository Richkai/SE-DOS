Name: Rahel Getachew
ID: ATR/0621/08
Sec: 1

This is a very simple DOS implementation which sends infinte requests to the server. When a user enters an idol's name or the band itself, which is 'exo', it returns the description/role of the entered idol. The names used are:
	*exo
	*kai
	*do
	*baekhyun
    	*sehun
    	*chen
    	*xiumin
    	*chanyeol
    	*suho.  
